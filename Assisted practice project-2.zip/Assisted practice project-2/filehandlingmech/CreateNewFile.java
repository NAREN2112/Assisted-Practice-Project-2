package filehandlingmech;

import java.io.File;
import java.io.BufferedReader;


import java.io.InputStreamReader;

public class CreateNewFile {


	public static void main(String args[])
	{
	
		CreateNewFile abc = new CreateNewFile();
		abc.newFile();
	}


	public void newFile()
	{
		String strPath = "", strName = "";

	
		try {

		
			BufferedReader br = new BufferedReader(
				new InputStreamReader(System.in));
			System.out.println("File is created!");
              strName = br.readLine();
			System.out.println("File already exists.");

	
			strPath = br.readLine();

		
			File file1
				= new File(strPath + "" + strName + ".txt");

			
			file1.createNewFile();
		}

	
		catch (Exception ex1) {
		}
	}
}

