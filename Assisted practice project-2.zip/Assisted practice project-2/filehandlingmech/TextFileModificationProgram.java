package filehandlingmech;
import java.io.FileWriter;

public class TextFileModificationProgram {
  public static void main(String args[]) {

    
    String program = "class JavaFile { " +
                       "public static void main(String[] args) { " +
                         "System.out.println(\"This is file\");"+
                       "}"+
                     "}";
     try {
      
       FileWriter output = new FileWriter("JavaFile.java");

       
       output.write(program);
       System.out.println("Done");

       
       output.close();
     }
     catch (Exception e) {
       e.getStackTrace();
     }
  }
}
